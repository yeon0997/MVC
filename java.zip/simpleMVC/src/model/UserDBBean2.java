package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDBBean2 {
	static final String driver = "com.mysql.cj.jdbc.Driver";
	static final String url = "jdbc:mysql://localhost:3306/simplemvc?serverTimezone=UTC";
	static final String userid = "root";
	static final String userpw = "1234";
		
	//1. connectDB, closeDB 는 메소드로 분리
	//2. DB접속해제 부분을 제외하고는 UserSearch 메소드로 분리 
	/* 0. UserInsert 메소드를 추가 
	 * index.jsp 에서 받아와서 controller가 가지고 있는 회원정보를
	 * DB에 넘겨주는 부분으로 추가 insert into member (?, ?, ?) ->  
	 * user.getfirstname(), user.getlastname(), user.getemail()
	 */
	//3. Search한 결과를 result.jsp 에 출력되도록 함. 

	
	public static void main(String[] args) throws SQLException {
	
	Connection conn = null; 
	PreparedStatement pstmt = null; 
	ResultSet rs = null; 
		
	//1. DB접속
	System.out.print("DB 접속 : ");
	try {
		Class.forName(driver); //드라이버 연결
		conn = DriverManager.getConnection(url, userid, userpw);
		if(conn != null) System.out.println("성공");
		else System.out.println("실패");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		System.out.print("ClassNotFoundException : ");
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.print("SQLException : ");
		e.printStackTrace();
	}
		
	//2. PreparedStatement 문 준비 -> 쿼리전송	
	String sql = "select * from member;";
	pstmt = conn.prepareStatement(sql);
	
	//3. ResultSet 받기 
	rs = pstmt.executeQuery();
	
	//4. ResultSet 결과물 출력해보기 -> rs.getString()
	while(rs.next()) { 
		System.out.println("FIRST NAME : " + rs.getString("firstname"));
		System.out.println("LAST NAME : " + rs.getString("lastname"));
		System.out.println("EMAIL : " + rs.getString("email"));
	}
	
	//5. PreparedStatement, ResultSet, Conn 해제 -> close()	
	pstmt.close();
	rs.close();
	conn.close();
	}
}